<?php $__env->startSection('title', 'Edit Materi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <form action="<?php echo e(route('updatemateri', $materi->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
            
            <div class="col-md-8">
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Edit Konten Materi</h3>
                    </div>
                    <div class="card-body">

                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><i class="fas fa-exclamation-triangle"></i> Gagal!</strong> Mohon periksa kembali isian Anda.
                                <ul class="mb-0 pl-4">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="judul">Judul Materi</label>
                            <input type="text" class="form-control form-control-lg" id="judul" name="judul" value="<?php echo e(old('judul', $materi->judul)); ?>" placeholder="Masukkan Judul Materi" required>
                        </div>

                        <div class="form-group">
                            <label for="konten">Isi Konten</label>
                            <textarea class="form-control" id="konten" name="konten" rows="18" placeholder="Tulis isi materi di sini..." required><?php echo e(old('konten', $materi->konten)); ?></textarea>
                            <small class="form-text text-muted">Anda bisa menggunakan baris baru untuk membuat paragraf.</small>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-md-4">
                <div class="card card-secondary">
                    <div class="card-header">
                        <h3 class="card-title">Media Utama</h3>
                    </div>
                    <div class="card-body">
                        
                        <div class="form-group">
                            <label for="link_yt">Link Video YouTube (Opsional)</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fab fa-youtube"></i></span>
                                </div>
                                <input type="url" class="form-control" id="link_yt" name="link_yt" value="<?php echo e(old('link_yt', $materi->link_yt)); ?>" placeholder="Contoh: https://youtube.com/watch?v=...">
                            </div>
                            <small class="form-text text-muted">Akan diprioritaskan di atas gambar.</small>
                        </div>

                        <hr>

                        <div class="form-group">
                            <label>Gambar (Digunakan jika tidak ada video)</label><br>
                            <?php if($materi->gambar): ?>
                                <a href="<?php echo e(asset('storage/' . $materi->gambar)); ?>" target="_blank" title="Lihat gambar penuh">
                                    <img src="<?php echo e(asset('storage/' . $materi->gambar)); ?>" alt="Gambar Materi" class="img-fluid rounded mb-2" style="max-height: 150px; width: 100%; object-fit: cover;">
                                </a>
                            <?php else: ?>
                                <p class="text-muted">Tidak ada gambar.</p>
                            <?php endif; ?>

                            <label for="gambar" class="mt-2">Ubah Gambar (Opsional)</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="gambar" name="gambar" accept="image/*">
                                <label class="custom-file-label" for="gambar">Pilih file baru...</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <a href="<?php echo e(route('materi')); ?>" class="btn btn-secondary btn-block mb-2">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fas fa-save"></i> Update Materi
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Script untuk menampilkan nama file di input file bootstrap
    $(function () {
        bsCustomFileInput.init();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadil/fadil/rahmat/admin-game/resources/views/materi/editMateri.blade.php ENDPATH**/ ?>