<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">FORM EDIT</h3>
            </div>

            <form action="<?php echo e(route('updateuser', $user->id)); ?>" method="POST">
              <div class="card-body">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label>Nama</label>
                  <input type="text" class="form-control" name="nama" value="<?php echo e($user->nama); ?>" placeholder="Input Nama">
                </div>
                <div class="form-group">
                  <label>NISN</label>
                  <input type="number" class="form-control" name="nisn" value="<?php echo e($user->nisn); ?>" placeholder="Input NISN">
                </div>

              </div>

              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Edit</button>
              </div>
            </form>
          </div>
        </div>
      </div>
  </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\belajar_laravel\resources\views/admin/edituser.blade.php ENDPATH**/ ?>