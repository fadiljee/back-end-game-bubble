<?php $__env->startSection('title', 'Edit Kuis'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('updatekuis', $kuis->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> 

                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title"><?php echo $__env->yieldContent('title'); ?>: <?php echo e(Str::limit($kuis->pertanyaan, 30)); ?></h3>
                    </div>
                    <div class="card-body">

                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong><i class="fas fa-exclamation-triangle"></i> Gagal Validasi!</strong>
                                <ul class="mb-0 pl-4">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="pertanyaan">Pertanyaan</label>
                            <textarea class="form-control" name="pertanyaan" rows="3" placeholder="Masukkan pertanyaan kuis..." required><?php echo e(old('pertanyaan', $kuis->pertanyaan)); ?></textarea>
                        </div>

                        <hr>
                        <p class="font-weight-bold">Pilihan Jawaban</p>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jawaban_a">Jawaban A</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><b>A</b></span>
                                        </div>
                                        <input type="text" class="form-control" name="jawaban_a" value="<?php echo e(old('jawaban_a', $kuis->jawaban_a)); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jawaban_b">Jawaban B</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><b>B</b></span>
                                        </div>
                                        <input type="text" class="form-control" name="jawaban_b" value="<?php echo e(old('jawaban_b', $kuis->jawaban_b)); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jawaban_c">Jawaban C</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><b>C</b></span>
                                        </div>
                                        <input type="text" class="form-control" name="jawaban_c" value="<?php echo e(old('jawaban_c', $kuis->jawaban_c)); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="jawaban_d">Jawaban D</label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><b>D</b></span>
                                        </div>
                                        <input type="text" class="form-control" name="jawaban_d" value="<?php echo e(old('jawaban_d', $kuis->jawaban_d)); ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <p class="font-weight-bold">Konfigurasi Soal</p>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="jawaban_benar">Kunci Jawaban</label>
                                    <select class="form-control select2" name="jawaban_benar" required>
                                        
                                        <option value="A" <?php if(old('jawaban_benar', $kuis->jawaban_benar) == 'A'): ?> selected <?php endif; ?>>Jawaban A</option>
                                        <option value="B" <?php if(old('jawaban_benar', $kuis->jawaban_benar) == 'B'): ?> selected <?php endif; ?>>Jawaban B</option>
                                        <option value="C" <?php if(old('jawaban_benar', $kuis->jawaban_benar) == 'C'): ?> selected <?php endif; ?>>Jawaban C</option>
                                        <option value="D" <?php if(old('jawaban_benar', $kuis->jawaban_benar) == 'D'): ?> selected <?php endif; ?>>Jawaban D</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="nilai">Nilai Soal (Poin)</label>
                                    <input type="number" class="form-control" name="nilai" value="<?php echo e(old('nilai', $kuis->nilai)); ?>" min="1" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="waktu_pengerjaan">Waktu Pengerjaan (detik)</label>
                                    <input type="number" class="form-control" name="waktu_pengerjaan" value="<?php echo e(old('waktu_pengerjaan', $kuis->waktu_pengerjaan)); ?>" min="10" required>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Kuis
                        </button>
                        <a href="<?php echo e(route('kuis')); ?>" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>
                </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadil/fadil/rahmat/admin-game/resources/views/quiz/edit.blade.php ENDPATH**/ ?>