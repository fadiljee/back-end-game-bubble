

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h1 class="text-center">Leaderboard</h1>
    
    <?php if(isset($leaderboard) && $leaderboard->count() > 0): ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Ranking</th>
                    <th>Nama Siswa</th>
                    <th>Total Nilai</th>
                    <th>Total Waktu (detik)</th>
                </tr>
            </thead>
            <tbody>
               <?php $rank = 1; ?>
<?php $__currentLoopData = $leaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($rank++); ?></td>
    <td><?php echo e($item->siswa->nama ?? 'Data Siswa Tidak Ditemukan'); ?></td>
    <td><?php echo e($item->total_nilai); ?></td>
    <td><?php echo e($item->total_waktu); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center">Tidak ada data leaderboard.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-game\resources\views/leaderboard/index.blade.php ENDPATH**/ ?>