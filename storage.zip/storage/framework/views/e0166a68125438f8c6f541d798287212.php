<?php $__env->startSection('title', 'Tambah Materi Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('title'); ?></h3>
                </div>
                
                <form action="<?php echo e(route('prosestambah')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <h5 class="font-weight-bold">Gagal Menyimpan!</h5>
                                <ul class="mb-0 pl-4">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="form-group">
                            <label for="judul">Judul Materi</label>
                            <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e(old('judul')); ?>" placeholder="Masukkan judul materi" required>
                        </div>

                        <div class="form-group">
                            <label for="konten">Konten Materi</label>
                            <textarea class="form-control" id="konten" name="konten" rows="5" placeholder="Masukkan isi konten materi" required><?php echo e(old('konten')); ?></textarea>
                        </div>

                        <hr>
                        <p class="text-muted">Pilih salah satu media di bawah ini (opsional):</p>

                        
                        <div class="form-group">
                            <label for="link_yt">Link Video YouTube</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fab fa-youtube"></i></span>
                                </div>
                                <input type="url" class="form-control" id="link_yt" name="link_yt" value="<?php echo e(old('link_yt')); ?>" placeholder="Contoh: https://www.youtube.com/watch?v=xxxxxxxxxxx">
                            </div>
                            <small class="form-text text-muted">Jika diisi, video ini akan ditampilkan sebagai media utama.</small>
                        </div>

                        
                        <div class="form-group">
                            <label for="gambar">Atau Unggah Gambar</label>
                            <div class="custom-file">
                                <input type="file" class="custom-file-input" id="gambar" name="gambar" accept="image/*">
                                <label class="custom-file-label" for="gambar">Pilih file gambar...</label>
                            </div>
                             <small class="form-text text-muted">Akan digunakan jika tidak ada link YouTube yang dimasukkan.</small>
                        </div>

                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('materi')); ?>" class="btn btn-secondary">Batal</a>
                        <button type="submit" class="btn btn-primary float-right">
                            <i class="fas fa-save mr-1"></i> Simpan Materi
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Script untuk menampilkan nama file di input file bootstrap
    $(function () {
        bsCustomFileInput.init();
    });
</script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadil/fadil/rahmat/admin-game/resources/views/materi/tambahMateri.blade.php ENDPATH**/ ?>