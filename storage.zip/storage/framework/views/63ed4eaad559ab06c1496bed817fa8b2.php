

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <?php if($errors->any()): ?>
              <ul style="color:red;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>

            <div class="card-header">
              <h3 class="card-title">Tambah Kuis</h3>
            </div>

            <form action="<?php echo e(route('prosestambahkuis')); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <div class="card-body">
                <!-- Pertanyaan -->
                <div class="form-group">
                  <label for="pertanyaan">Pertanyaan</label>
                  <input type="text" class="form-control" name="pertanyaan" value="<?php echo e(old('pertanyaan')); ?>" required>
                </div>

                <!-- Pilihan Jawaban -->
                <div class="form-group">
                  <label for="jawaban_a">Jawaban A</label>
                  <input type="text" class="form-control" name="jawaban_a" value="<?php echo e(old('jawaban_a')); ?>" required>
                </div>

                <div class="form-group">
                  <label for="jawaban_b">Jawaban B</label>
                  <input type="text" class="form-control" name="jawaban_b" value="<?php echo e(old('jawaban_b')); ?>" required>
                </div>

                <div class="form-group">
                  <label for="jawaban_c">Jawaban C</label>
                  <input type="text" class="form-control" name="jawaban_c" value="<?php echo e(old('jawaban_c')); ?>" required>
                </div>

                <div class="form-group">
                  <label for="jawaban_d">Jawaban D</label>
                  <input type="text" class="form-control" name="jawaban_d" value="<?php echo e(old('jawaban_d')); ?>" required>
                </div>

                <!-- Pilihan Jawaban Benar -->
                <div class="form-group">
                  <label for="jawaban_benar">Jawaban Benar</label>
                  <select class="form-control" name="jawaban_benar" required>
                    <option value="">Pilih Jawaban Benar</option>
                    <option value="A" <?php echo e(old('jawaban_benar') == 'A' ? 'selected' : ''); ?>>A</option>
                    <option value="B" <?php echo e(old('jawaban_benar') == 'B' ? 'selected' : ''); ?>>B</option>
                    <option value="C" <?php echo e(old('jawaban_benar') == 'C' ? 'selected' : ''); ?>>C</option>
                    <option value="D" <?php echo e(old('jawaban_benar') == 'D' ? 'selected' : ''); ?>>D</option>
                  </select>
                </div>

                <!-- Pilihan Materi -->
                <div class="form-group">
                  <label for="materi_id">Pilih Materi</label>
                  <select class="form-control" name="materi_id" required>
                    <option value="">Pilih Materi</option>
                    <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($materi->id); ?>" <?php echo e(old('materi_id') == $materi->id ? 'selected' : ''); ?>><?php echo e($materi->judul); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
              </div>

              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Tambah Kuis</button>
              </div>
            </form>
          </div>
        </div>
      </div>
  </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-ab\resources\views/quiz/create.blade.php ENDPATH**/ ?>