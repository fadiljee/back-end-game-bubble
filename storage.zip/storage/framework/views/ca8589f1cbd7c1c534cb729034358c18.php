<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="card card-primary">
            

            <?php if($errors->any()): ?>
            <ul style="color:red;">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li> <?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>

            

            <div class="card-header">
              <h3 class="card-title">Data Siswa</h3>
            </div>
  
            <?php if(session('success')): ?>
            <p style="color:green"> <?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                
                <a href="<?php echo e(route('formregister')); ?>" class="btn btn-success"><i class="nav-icon fas fa-user-plus"></i>Tambah</a>
                <thead>
                  <tr>
                    <th>Nama</th>
                    <th>NISN</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->nisn); ?></td>
                    <td>
                      <a href="<?php echo e(route('useredit', $user->id)); ?>" class="btn btn-primary">Edit</a> |
                      <form action="<?php echo e(route('userdelete', $user->id)); ?>" method="post" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger"  onclick="return confirm('Yakin ingin menghapus data ini?');">Hapus</button>
                      </form>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div> <!-- /.card-body -->
        <div class="col-12">
          <div class="card">
          </div> <!-- /.card -->
        </div> <!-- /.col -->
      </div>
  </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-ab\resources\views/admin/formhitung.blade.php ENDPATH**/ ?>