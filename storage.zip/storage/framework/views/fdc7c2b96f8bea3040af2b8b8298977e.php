

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <?php if($errors->any()): ?>
              <ul style="color:red;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>

            <div class="card-header">
              <h3 class="card-title">Data Kuis</h3>
            </div>

            <?php if(session('success')): ?>
              <p style="color:green"><?php echo e(session('success')); ?></p>
            <?php endif; ?>

            <div class="card-body">
              <a href="<?php echo e(route('tambahkuis')); ?>" class="btn btn-success"><i class="nav-icon fas fa-plus"></i>Tambah Kuis</a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Pertanyaan</th>
                    <th>Jawaban A</th>
                    <th>Jawaban B</th>
                    <th>Jawaban C</th>
                    <th>Jawaban D</th>
                    <th>Jawaban Benar</th>
                    <th>Waktu Pengerjaan (detik)</th> 
                    <th>Nilai Soal</th>

                    
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $kuis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($item->pertanyaan); ?></td>
                      <td><?php echo e($item->jawaban_a); ?></td>
                      <td><?php echo e($item->jawaban_b); ?></td>
                      <td><?php echo e($item->jawaban_c); ?></td>
                      <td><?php echo e($item->jawaban_d); ?></td>
                      <td><?php echo e($item->jawaban_benar); ?></td>
                      <td><?php echo e($item->waktu_pengerjaan); ?></td> 
                      <td><?php echo e($item->nilai); ?></td>

                      <td>
                        <a href="<?php echo e(route('kuisedit', $item->id)); ?>" class="btn btn-primary">Edit</a> |
                        <form action="<?php echo e(route('kuisdelete', $item->id)); ?>" method="POST" style="display: inline;">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus kuis ini?');">Hapus</button>
                        </form>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
  </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-game\resources\views/quiz/index.blade.php ENDPATH**/ ?>