<?php $__env->startSection('title', 'Manajemen Kuis'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('title'); ?></h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('tambahkuis')); ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-plus"></i> Tambah Kuis
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <strong>Gagal!</strong>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                    <?php endif; ?>

                    
                    
                    <table id="kuis-table" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th style="width: 5%;">No</th>
                                <th>Pertanyaan</th>
                                <th class="text-center">Jawaban Benar</th>
                                <th class="text-center">Waktu (detik)</th>
                                <th class="text-center">Nilai Soal</th>
                                <th class="text-center" style="width: 10%;">Aksi</th>

                                
                                <th class="d-none">Jawaban A</th>
                                <th class="d-none">Jawaban B</th>
                                <th class="d-none">Jawaban C</th>
                                <th class="d-none">Jawaban D</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kuis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td class="font-weight-bold"><?php echo e($item->pertanyaan); ?></td>
                                <td class="text-center">
                                    <span class="badge bg-success" style="font-size: 0.9rem;"><?php echo e($item->jawaban_benar); ?></span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-info"><?php echo e($item->waktu_pengerjaan); ?> detik</span>
                                </td>
                                <td class="text-center">
                                    <span class="badge bg-purple"><?php echo e($item->nilai); ?> Poin</span>
                                </td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('kuisdelete', $item->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kuis ini?');">
                                        <a href="<?php echo e(route('kuisedit', $item->id)); ?>" class="btn btn-warning btn-xs" title="Edit Kuis">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-xs" title="Hapus Kuis">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </td>

                                
                                <td class="d-none"><?php echo e($item->jawaban_a); ?></td>
                                <td class="d-none"><?php echo e($item->jawaban_b); ?></td>
                                <td class="d-none"><?php echo e($item->jawaban_c); ?></td>
                                <td class="d-none"><?php echo e($item->jawaban_d); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Inisialisasi DataTables dengan fitur responsif
    $(function () {
        $('#kuis-table').DataTable({
            "responsive": true,
            "lengthChange": false,
            "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
            // Mengatur kolom mana yang selalu terlihat dan mana yang bisa disembunyikan
            "columnDefs": [
                { "responsivePriority": 1, "targets": 1 }, // Pertanyaan
                { "responsivePriority": 2, "targets": 5 }, // Aksi
                { "responsivePriority": 3, "targets": 2 }, // Jawaban Benar
                // Kolom Jawaban A-D akan otomatis disembunyikan jika tidak cukup ruang
            ]
        }).buttons().container().appendTo('#kuis-table_wrapper .col-md-6:eq(0)');
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadil/fadil/rahmat/admin-game/resources/views/quiz/index.blade.php ENDPATH**/ ?>