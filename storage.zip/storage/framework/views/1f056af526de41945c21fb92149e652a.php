

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">

            <div class="card-header">
              <h3 class="card-title">Daftar Hasil Kuis</h3>
            </div>

            <div class="card-body">
              <?php if($hasilKuis->isEmpty()): ?>
                <p>Tidak ada data hasil kuis.</p>
              <?php else: ?>
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>Nama Siswa</th>
                      <th>Soal</th>
                      <th>Jawaban User</th>
                      <th>Status</th>
                      <th>Waktu (detik)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $hasilKuis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($hasil->siswa->nama ?? 'Data Siswa Tidak Ditemukan'); ?></td>
                        <td><?php echo e($hasil->kuis->pertanyaan ?? 'Soal Tidak Ditemukan'); ?></td>
                        <td><?php echo e($hasil->jawaban_user); ?></td>
                        <td>
                            <?php $__currentLoopData = $nilaiPerSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswaId => $nilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <p>Siswa ID <?php echo e($siswaId); ?> Nilai Total: <?php echo e($nilai); ?></p>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if($hasil->benar): ?>
                            <span class="badge badge-success">Benar</span>
                          <?php else: ?>
                            <span class="badge badge-danger">Salah</span>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($hasil->waktu); ?></td>
                      </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              <?php endif; ?>
            </div>

          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-game\resources\views/hasilkuis/index.blade.php ENDPATH**/ ?>