<?php $__env->startSection('title', 'Rekapitulasi Hasil Kuis'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('title'); ?></h3>
                    
                    <div class="card-tools">
                        <?php if(!empty($groupedResults)): ?>
                        <button id="btn-delete-all" class="btn btn-danger btn-sm">
                            <i class="fas fa-trash-alt"></i> Hapus Semua Hasil
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body">
                    <?php if(empty($groupedResults)): ?>
                        <div class="text-center py-5">
                            <i class="fas fa-chart-bar fa-4x text-muted mb-3"></i>
                            <h4 class="font-weight-bold">Belum Ada Hasil Kuis</h4>
                            <p class="text-muted">Data akan muncul di sini setelah siswa mengerjakan kuis.</p>
                        </div>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table id="hasil-kuis-table" class="table table-bordered table-hover">
                                <thead class="text-center thead-light">
                                    <tr>
                                        <th rowspan="2" class="align-middle">Ranking</th>
                                        <th rowspan="2" class="align-middle">Nama Siswa</th>
                                        <th rowspan="2" class="align-middle">NISN</th>
                                        <th colspan="<?php echo e($allQuestions->count()); ?>">Jawaban per Soal</th>
                                        <th rowspan="2" class="align-middle">Total Nilai</th>
                                        <th rowspan="2" class="align-middle">Total Waktu (detik)</th>
                                        
                                        <th rowspan="2" class="align-middle">Aksi</th>
                                    </tr>
                                    <tr>
                                        <?php $__currentLoopData = $allQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th title="<?php echo e($question->pertanyaan); ?>"><?php echo e($loop->iteration); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__currentLoopData = $groupedResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="row-siswa-<?php echo e($result['siswa_id']); ?>"> 
                                            <td class="text-center font-weight-bold"><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($result['siswa_nama']); ?></td>
                                            <td><?php echo e($result['siswa_nisn']); ?></td>

                                            <?php $__currentLoopData = $allQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $answerData = $result['answers'][$question->id] ?? null;
                                                ?>
                                                <td class="text-center">
                                                    <?php if($answerData): ?>
                                                        <?php if($answerData['benar']): ?>
                                                            <span class="badge bg-success" title="Benar"><?php echo e($answerData['jawaban']); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger" title="Salah"><?php echo e($answerData['jawaban']); ?></span>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary" title="Tidak Dijawab">-</span>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            <td class="text-center font-weight-bold bg-light"><?php echo e($result['total_nilai']); ?></td>
                                            <td class="text-center text-muted"><?php echo e($result['total_waktu']); ?></td>
                                            
                                            <td class="text-center">
                                                <button class="btn btn-danger btn-sm btn-delete" data-id="<?php echo e($result['siswa_id']); ?>" data-nama="<?php echo e($result['siswa_nama']); ?>" title="Hapus hasil kuis siswa ini">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function () {
        // Inisialisasi DataTables
        var table = $('#hasil-kuis-table').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print"]
        }).buttons().container().appendTo('#hasil-kuis-table_wrapper .col-md-6:eq(0)');

        // Setup CSRF Token untuk semua request AJAX
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        // AKSI HAPUS SATU DATA (EVENT DELEGATION)
        $('#hasil-kuis-table tbody').on('click', '.btn-delete', function () {
            var siswaId = $(this).data('id');
            var siswaNama = $(this).data('nama');
            var url = "<?php echo e(route('hasilkuis.destroy', ['siswa_id' => ':id'])); ?>".replace(':id', siswaId);

            Swal.fire({
                title: 'Anda Yakin?',
                text: `Hasil kuis milik "${siswaNama}" akan dihapus secara permanen!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        success: function(response) {
                            Swal.fire(
                                'Dihapus!',
                                response.success,
                                'success'
                            );
                            // Hapus baris dari DataTable tanpa reload halaman
                            table.row('#row-siswa-' + siswaId).remove().draw(false);
                        },
                        error: function(xhr) {
                            Swal.fire(
                                'Gagal!',
                                'Terjadi kesalahan saat menghapus data.',
                                'error'
                            );
                        }
                    });
                }
            });
        });

        // AKSI HAPUS SEMUA DATA
        $('#btn-delete-all').on('click', function() {
            var url = "<?php echo e(route('hasilkuis.destroyAll')); ?>";

            Swal.fire({
                title: 'ANDA SANGAT YAKIN?',
                text: "Semua data hasil kuis akan dihapus dan tidak dapat dikembalikan!",
                icon: 'error',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus Semuanya!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: url,
                        type: 'DELETE',
                        success: function(response) {
                            Swal.fire(
                                'Berhasil!',
                                response.success,
                                'success'
                            ).then(() => {
                                // Reload halaman untuk melihat tabel yang sudah kosong
                                location.reload();
                            });
                        },
                        error: function(xhr) {
                            Swal.fire(
                                'Gagal!',
                                'Terjadi kesalahan saat menghapus semua data.',
                                'error'
                            );
                        }
                    });
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/fadil/fadil/rahmat/admin-game/resources/views/hasilkuis/index.blade.php ENDPATH**/ ?>