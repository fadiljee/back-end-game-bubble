

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <?php if($errors->any()): ?>
            <ul style="color:red;">
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li> <?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>

            <div class="card-header">
              <h3 class="card-title">Data Materi</h3>
            </div>

            <?php if(session('success')): ?>
            <p style="color:green"> <?php echo e(session('success')); ?></p>
            <?php endif; ?>

            <div class="card-body">
              <a href="<?php echo e(route('tambahMateri')); ?>" class="btn btn-success"><i class="nav-icon fas fa-plus"></i>Tambah Materi</a>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
  <tr>
    <th>Judul</th>
    <th>Gambar</th> 
    <th>Konten</th>
    <th>Aksi</th>
  </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $materis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $materi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td><?php echo e($materi->judul); ?></td>
    <td>
      <?php if($materi->gambar): ?>
        <img src="<?php echo e(asset('storage/' . $materi->gambar)); ?>" alt="Gambar Materi" style="max-width: 100px; height: auto;">
      <?php else: ?>
        <span>Tidak ada gambar</span>
      <?php endif; ?>
    </td>
    <td><?php echo e(\Str::limit($materi->konten, 50)); ?></td>
    <td>
      <a href="<?php echo e(route('materiedit', $materi->id)); ?>" class="btn btn-primary">Edit</a> |
      <form action="<?php echo e(route('materidelete', $materi->id)); ?>" method="post" style="display: inline;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus materi ini?');">Hapus</button>
      </form>
    </td>
  </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

              </table>
            </div>
          </div>
        </div>
      </div>
  </section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\admin-game\resources\views/materi/index.blade.php ENDPATH**/ ?>